// Inlines chess.js v1.4.0 into openingtrainer.html so the rules engine needs
// no network — the trainer then works fully offline on a phone. Idempotent.
const fs = require('fs');

let html = fs.readFileSync('openingtrainer.html', 'utf8');

if (html.includes('chess.js v1.4.0 — bundled')) {
  console.log('already bundled; nothing to do');
  process.exit(0);
}

// build a global-exposing bundle from the locally-installed ESM source
let chess = fs.readFileSync('node_modules/chess.js/dist/esm/chess.js', 'utf8');
chess = chess.replace(/^export \{[^}]*\};\s*$/m, '');          // drop the ESM export
chess = chess.replace(/^\/\/# sourceMappingURL=.*$/m, '');     // drop sourcemap ref
const bundle =
  '<script>/* chess.js v1.4.0 — bundled for offline use (no CDN needed) */\n' +
  '(function(){\n' + chess + '\n;globalThis.Chess = Chess;})();\n</script>\n';

// insert the bundle right before the module script
const moduleTag = '<script type="module">';
if (!html.includes(moduleTag)) { console.error('module script not found'); process.exit(1); }
html = html.replace(moduleTag, bundle + moduleTag);

// replace the CDN loader with a reference to the bundled global
const loader = `/* ---- load chess engine (two CDNs + offline fallback message) ---- */
let Chess;
try { ({ Chess } = await import('https://esm.sh/chess.js@1.4.0')); }
catch (e1) {
  try { ({ Chess } = await import('https://cdn.jsdelivr.net/npm/chess.js@1.4.0/+esm')); }
  catch (e2) {
    document.getElementById('app').innerHTML =
      '<div class="center"><div class="card" style="max-width:440px">' +
      '<h2>Couldn’t load the chess engine</h2>' +
      '<p class="muted">This page needs an internet connection the first time you open it ' +
      '(to fetch the rules engine, which your browser then caches). Please check your ' +
      'connection and reopen the file.</p></div></div>';
    throw e2;
  }
}`;
const replacement = `/* ---- chess engine is bundled inline above (works offline) ---- */
const Chess = globalThis.Chess;
if (!Chess) {
  document.getElementById('app').innerHTML =
    '<div class="center"><div class="card" style="max-width:440px"><h2>Couldn’t start the chess engine</h2>' +
    '<p class="muted">The bundled rules engine failed to initialise — please reopen the app.</p></div></div>';
  throw new Error('bundled chess.js not found');
}`;
if (!html.includes(loader)) { console.error('loader block not found — aborting'); process.exit(1); }
html = html.replace(loader, replacement);

fs.writeFileSync('openingtrainer.html', html);
console.log('bundled chess.js into openingtrainer.html (' + html.length + ' chars)');
