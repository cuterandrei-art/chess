// Generates the installable PWA `index.html` from the standalone
// `openingtrainer.html` by injecting PWA head tags + service-worker
// registration. Re-run this whenever openingtrainer.html changes.
const fs = require('fs');

let html = fs.readFileSync('openingtrainer.html', 'utf8');

const HEAD = `
<meta name="theme-color" content="#0b1120" />
<meta name="description" content="Learn and drill chess opening repertoires with spaced repetition, a per-opening course checklist, and play vs Stockfish." />
<meta name="mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
<meta name="apple-mobile-web-app-title" content="OpeningTrainer" />
<link rel="manifest" href="manifest.webmanifest" />
<link rel="icon" type="image/png" sizes="32x32" href="favicon-32.png" />
<link rel="icon" type="image/png" sizes="192x192" href="icon-192.png" />
<link rel="apple-touch-icon" href="apple-touch-icon.png" />`;

const SW = `
<script>
  if ('serviceWorker' in navigator) {
    addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
  }
  // Lightweight "Install app" affordance (Android/desktop). iOS: Share → Add to Home Screen.
  (function () {
    let deferred = null;
    const btn = document.createElement('button');
    btn.textContent = '⬇ Install app';
    btn.style.cssText = 'position:fixed;right:14px;bottom:14px;z-index:9999;display:none;border:0;border-radius:10px;padding:10px 14px;font:600 14px Inter,system-ui,sans-serif;background:#1c84f5;color:#fff;box-shadow:0 8px 24px rgba(0,0,0,.4);cursor:pointer';
    document.body.appendChild(btn);
    window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferred = e; btn.style.display = 'block'; });
    btn.addEventListener('click', async () => { if (!deferred) return; deferred.prompt(); await deferred.userChoice; deferred = null; btn.style.display = 'none'; });
    window.addEventListener('appinstalled', () => { btn.style.display = 'none'; });
  })();
</script>`;

const viewport = '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />';
if (html.indexOf(viewport) < 0) { console.error('viewport meta not found'); process.exit(1); }
html = html.replace(viewport, viewport + HEAD);

if (html.indexOf('</body>') < 0) { console.error('</body> not found'); process.exit(1); }
html = html.replace('</body>', SW + '\n</body>');

fs.writeFileSync('index.html', html);
console.log('wrote index.html (' + html.length + ' chars)');
