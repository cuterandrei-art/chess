// Generates Android launcher icons (mipmap densities) from the knight SVG.
const fs = require('fs');
const sharp = require('sharp');

const KNIGHT = '&#9822;'; // ♞
function svg(size, { round = false } = {}) {
  const fontPx = Math.round(size * (round ? 0.62 : 0.58));
  const rx = round ? 0 : Math.round(size * 0.22);
  const sh = Math.round(size * 0.012);
  const y = Math.round(size * 0.55);
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
  <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="#33a2ff"/><stop offset="0.55" stop-color="#1c84f5"/><stop offset="1" stop-color="#0b4ea0"/>
  </linearGradient></defs>
  <rect x="0" y="0" width="${size}" height="${size}" rx="${rx}" ry="${rx}" fill="url(#g)"/>
  <text x="50%" y="${y}" font-family="DejaVu Sans, sans-serif" font-size="${fontPx}" text-anchor="middle" dominant-baseline="central" fill="#0a1020" fill-opacity="0.25" dy="${sh}">${KNIGHT}</text>
  <text x="50%" y="${y}" font-family="DejaVu Sans, sans-serif" font-size="${fontPx}" text-anchor="middle" dominant-baseline="central" fill="#f8fafc">${KNIGHT}</text>
</svg>`;
}

const densities = { mdpi: 48, hdpi: 72, xhdpi: 96, xxhdpi: 144, xxxhdpi: 192 };
const base = 'android/app/src/main/res';

(async () => {
  for (const [d, size] of Object.entries(densities)) {
    const dir = `${base}/mipmap-${d}`;
    fs.mkdirSync(dir, { recursive: true });
    await sharp(Buffer.from(svg(size))).png().toFile(`${dir}/ic_launcher.png`);
    await sharp(Buffer.from(svg(size, { round: true }))).png().toFile(`${dir}/ic_launcher_round.png`);
    console.log('wrote', `mipmap-${d}`, size);
  }
})();
