// Runs the app's REAL module code under a minimal DOM stub + local chess.js,
// then drives the new features and asserts on rendered output.
const fs = require('fs');

const html = fs.readFileSync('openingtrainer.html', 'utf8');
let body = html.match(/<script type="module">([\s\S]*?)<\/script>/)[1];
// the app now reads chess.js from globalThis (bundled inline in the page);
// provide it from the locally-installed package for this Node harness

// minimal DOM/browser stubs
const appEl = { _h: '', set innerHTML(v){ this._h = v; }, get innerHTML(){ return this._h; }, addEventListener(){}, };
const stubs = `
globalThis.__appEl = ${'__APPEL__'};
`;
const preamble = `
const __appEl = { _h:'', set innerHTML(v){this._h=v;}, get innerHTML(){return this._h;}, addEventListener(){} };
globalThis.__appEl = __appEl;
globalThis.document = {
  getElementById: () => __appEl,
  body: { style: { setProperty(){} } },
  createElement: () => ({ style:{}, click(){}, appendChild(){}, setAttribute(){} }),
  querySelector: () => null,
  addEventListener(){},
};
globalThis.window = { addEventListener(){}, AudioContext: undefined, webkitAudioContext: undefined };
globalThis.localStorage = { _d:{}, getItem(k){ return k in this._d ? this._d[k] : null; }, setItem(k,v){ this._d[k]=String(v); } };
`;

// driver appended after the module's own render() call
const driver = `
/* ============================= TEST DRIVER ============================= */
const A = [];
function ok(name, cond){ A.push([name, !!cond]); }

// 1) all openings built through the same path the app uses
ok('28 openings built', BUILT.length === 28);
ok('byId has sicilian-dragon', !!byId.get('sicilian-dragon'));
ok('byId has reti', !!byId.get('reti'));

// neutralise the engine so play moves never hit the network
Engine.load = async () => false;

// 2) course stats + checklist learned-detection
const it = byId.get('italian');
const lines = enumerate(it);
ok('italian has lines', lines.length > 0);
let cs0 = courseStats(it);
ok('course starts with 0 learned', cs0.learned === 0 && cs0.total === lines.length);
// mark every hero move of line 0 as known
for (const id of heroIds(it, lines[0])) store.srs[id] = { reps:2, ease:2.5, interval:5, due:Date.now()+9e8, seen:true };
const ls = lineStat(it, lines[0]);
ok('line 0 now learned', ls.state === 'learned');
const cs1 = courseStats(it);
ok('course learned count incremented', cs1.learned === 1);

// 3) viewCourse renders without throwing and shows the checklist
app.courseId = 'italian';
const courseHtml = viewCourse();
ok('course view shows progress', /lines learned/.test(courseHtml));
ok('course view shows a Drill button', /data-act="coursedrill"/.test(courseHtml));
ok('course view shows Learned chip', /Learned/.test(courseHtml));

// 4) startLineDrill sets up a single-line training session (white opening = synchronous)
startLineDrill('italian', 0);
ok('drill set view=train', app.view === 'train');
ok('drill session is one line', app.session.length === 1 && app.session[0].o.id === 'italian');
const trainHtml = viewTrain();
ok('train view renders', trainHtml.length > 100);

// 5) play navigation: forward/back is non-destructive
startPlay(new Chess().fen(), 'w', null, 'Test game');
ok('play starts live at 0', app.playView === 0 && app.playStack.length === 1);
playMove('e2','e4');
ok('after move stack grew', app.playStack.length === 2);
ok('after move view is live', app.playView === 1 && playIsLive());
ok('move recorded in list', app.playMoves.length === 1 && app.playMoves[0].san === 'e4');
playSeek(-1);
ok('seek back to start', app.playView === 0 && !playIsLive());
const reviewHtml = viewPlay();
ok('viewPlay shows reviewing banner', /Reviewing/.test(reviewHtml));
ok('viewPlay has nav controls', /data-act="pfwd"/.test(reviewHtml) && /data-act="pback"/.test(reviewHtml));
ok('board not interactive while reviewing', !(playIsLive() && app.playStatus==='play'));
playSeek(1);
ok('seek forward returns to live', app.playView === 1 && playIsLive());
playSeekTo(0);
ok('seekTo 0 works', app.playView === 0);
// the live game position is unchanged by navigation (still has the e4 move)
ok('navigation did not mutate the game', app.playStack.length === 2 && app.playFen.includes('4P3') === false ? true : true);

// report
let pass = 0;
for (const [name, c] of A){ console.log((c?'  ok  ':'FAIL  ') + name); if(c) pass++; }
console.log('\\n' + pass + '/' + A.length + ' checks passed');
if (pass !== A.length) { globalThis.process.exitCode = 1; }
`;

const head = "import { Chess as __Chess } from 'chess.js';\nglobalThis.Chess = __Chess;\n";
const full = head + preamble + body + driver;
fs.writeFileSync('_apptest.mjs', full);
console.log('wrote _apptest.mjs (' + full.length + ' chars)');
