// Validates every opening line in openingtrainer.html against chess.js,
// the same engine the app uses at runtime. Also checks that every comment
// key is a real prefix of at least one line.
const fs = require('fs');
const { Chess } = require('chess.js');

const file = process.argv[2] || 'openingtrainer.html';
const html = fs.readFileSync(file, 'utf8');
const m = html.match(/\/\*OPENINGS_START\*\/([\s\S]*?)\/\*OPENINGS_END\*\//);
if (!m) { console.error('Could not find OPENINGS block'); process.exit(2); }

const OPENINGS = new Function(m[1] + '\nreturn OPENINGS;')(); // block defines const OPENINGS = [...]

let errors = 0, lineCount = 0, openingCount = 0;
const ids = new Set();
for (const o of OPENINGS) {
  openingCount++;
  if (ids.has(o.id)) { console.error(`DUPLICATE id: ${o.id}`); errors++; }
  ids.add(o.id);
  const prefixes = new Set();
  for (const ln of o.lines) {
    lineCount++;
    const c = new Chess();
    const moves = ln.trim().split(/\s+/);
    let prefix = '';
    for (const mv of moves) {
      prefix = prefix ? prefix + ' ' + mv : mv;
      prefixes.add(prefix);
      try { c.move(mv); }
      catch (e) {
        console.error(`ILLEGAL  [${o.id}]  "${mv}"  after  "${prefix.slice(0, prefix.length - mv.length).trim()}"\n         full: ${ln}`);
        errors++;
        break;
      }
    }
  }
  // comment keys must be prefixes of some line
  for (const key of Object.keys(o.comments || {})) {
    if (!prefixes.has(key)) {
      console.error(`BAD COMMENT KEY  [${o.id}]  "${key}"  is not a prefix of any line`);
      errors++;
    }
  }
}

console.log(`\nOpenings: ${openingCount}   Lines: ${lineCount}   Errors: ${errors}`);
process.exit(errors ? 1 : 0);
