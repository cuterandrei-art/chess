# ♞ OpeningTrainer

A self-contained chess **opening repertoire trainer**: learn lines with spaced
repetition, track your progress with a per-opening **course checklist**, explore
variations, and **play vs Stockfish**. Everything is saved privately in your
browser — no account, no server.

It runs three ways:

| Target | Use it for |
|------|------------|
| **`openingtrainer.html`** | A single, portable file. Open it in any browser — the rules engine is **bundled inline**, so the trainer works fully offline. |
| **`index.html`** + the icons / `manifest.webmanifest` / `sw.js` | The **installable web app** (PWA). Install from a phone browser; works offline. |
| **`android/`** | A native **Android app** (`WebView` wrapper) that builds to an installable **APK**. See [`android/README.md`](android/README.md). |

> `openingtrainer.html` is the source of truth. `index.html` is generated from it
> (`node build-bundle.js` inlines chess.js, then `node build-pwa.js` adds the
> install/offline wiring); the Android app bundles the same files under
> `android/app/src/main/assets/www/`.

---

## What's new in this version

- **Forward / back move navigation in Play.** While playing Stockfish you can now
  step through the whole game non-destructively with `⏮ ◀ Back / Forward ▶ ⏭`
  (or the arrow keys), tap any move in the move list to jump there, then **Jump to
  live** to keep playing. This is separate from *Take back*, which still rewinds
  the game.
- **Opening "course" progress tracker.** Every opening now has a **📋 Course**
  view: a checklist of all its lines. A line turns ✓ **Learned** once you've
  correctly played every one of *your* moves in it at least once; lines in
  progress show how many moves you've got. **Drill** any single line, or **Study**
  it in the explorer. Reach it from the Dashboard cards, the Library, or the
  opening explorer.
- **10 new openings** (28 total): Sicilian **Dragon** & **Sveshnikov**,
  **Queen's Indian**, **Slav**, **Petrov**, **Alekhine**, **Réti**,
  **Benko Gambit**, **Four Knights**, and the **Modern Defence**. Every line is
  validated for legality (see *Development* below).
- **Offline-ready & native Android.** The chess engine is now bundled into the
  page (no CDN needed for the trainer), and there's a native **Android app**
  that builds to an installable APK.

---

## Get it on Android (recommended)

A native APK — install once, launch from your app drawer, runs offline.

- **Easiest (no tools):** push this repo to GitHub. The **Build Android APK**
  workflow compiles `OpeningTrainer.apk` and attaches it to the **latest-android**
  pre-release (and to the run's Artifacts). Open that APK on your phone, allow
  "install unknown apps", and install.
- **Build locally:** open the `android/` folder in Android Studio and press
  **Run**, or `cd android && ./gradlew assembleDebug`. Full details in
  [`android/README.md`](android/README.md).

## Or install the web app (PWA)

Host the files (see **Hosting** below), open the URL in your phone browser, and
add it to your home screen — it launches full-screen and works offline.

- **Android (Chrome):** open the site → **⬇ Install app** button (or **⋮ → Install
  app**).
- **iPhone / iPad (Safari):** open the site → **Share** → **Add to Home Screen**.

## Hosting (GitHub Pages)

A workflow at `.github/workflows/pages.yml` deploys the app automatically.

1. In the repo, go to **Settings → Pages** and set **Source: GitHub Actions**
   (the workflow also tries to enable this for you).
2. Push to the deploy branch (or run the workflow from the **Actions** tab via
   **Run workflow**). If your work is on a feature branch and the deploy is
   blocked by environment rules, merge to your default branch and it will deploy.
3. The app goes live at **https://cuterandrei-art.github.io/chess/** — open that
   on your phone and install it.

You can host these files on any static host (Netlify, Vercel, your own server) —
just serve the repo root over HTTPS. (Service workers/installation need HTTPS or
`localhost`; opening `index.html` directly via `file://` works as a normal page
but can't install/offline-cache — use `openingtrainer.html` for that case.)

---

## Development

```bash
npm install                    # chess.js (validator) + sharp (icon generator)

node validate.js               # replay every opening line through chess.js
node runtime-test.js && node _apptest.mjs   # run the app's real code + feature checks
node gen-icons.js              # regenerate the app icons
node build-pwa.js              # regenerate index.html from openingtrainer.html
```

- `validate.js` — confirms every line in `openingtrainer.html` is legal and that
  comment keys are real prefixes.
- `runtime-test.js` — loads the app's actual module under a tiny DOM stub and
  asserts the new features (course checklist, line drill, play navigation) work.
