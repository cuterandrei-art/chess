// Generates PWA / home-screen icons (brand gradient + white knight) with sharp.
const fs = require('fs');
const sharp = require('sharp');

const KNIGHT = '&#9822;'; // ♞

function svg(size, { maskable = false, knightFrac = 0.6 } = {}) {
  const fontPx = Math.round(size * knightFrac);
  const rx = maskable ? 0 : Math.round(size * 0.22);
  const shadow = Math.round(size * 0.012);
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#33a2ff"/>
      <stop offset="0.55" stop-color="#1c84f5"/>
      <stop offset="1" stop-color="#0b4ea0"/>
    </linearGradient>
  </defs>
  <rect x="0" y="0" width="${size}" height="${size}" rx="${rx}" ry="${rx}" fill="url(#g)"/>
  <text x="50%" y="${Math.round(size * 0.55)}" font-family="DejaVu Sans, Noto Sans Symbols2, sans-serif"
        font-size="${fontPx}" text-anchor="middle" dominant-baseline="central"
        fill="#0a1020" fill-opacity="0.25" dx="0" dy="${shadow}">${KNIGHT}</text>
  <text x="50%" y="${Math.round(size * 0.55)}" font-family="DejaVu Sans, Noto Sans Symbols2, sans-serif"
        font-size="${fontPx}" text-anchor="middle" dominant-baseline="central"
        fill="#f8fafc">${KNIGHT}</text>
</svg>`;
}

const jobs = [
  ['icon-192.png', 192, { knightFrac: 0.6 }],
  ['icon-512.png', 512, { knightFrac: 0.6 }],
  ['icon-512-maskable.png', 512, { maskable: true, knightFrac: 0.5 }],
  ['apple-touch-icon.png', 180, { maskable: true, knightFrac: 0.6 }],
  ['favicon-32.png', 32, { knightFrac: 0.66 }],
];

(async () => {
  for (const [name, size, opts] of jobs) {
    await sharp(Buffer.from(svg(size, opts))).png().toFile(name);
    console.log('wrote', name, size + 'x' + size);
  }
  // sanity: bounding box of the knight in the maskable icon (alpha/contrast check)
  const { data, info } = await sharp(Buffer.from(svg(512, { maskable: true, knightFrac: 0.5 })))
    .greyscale().raw().toBuffer({ resolveWithObject: true });
  let minX = info.width, maxX = 0, minY = info.height, maxY = 0, n = 0;
  for (let y = 0; y < info.height; y++) for (let x = 0; x < info.width; x++) {
    if (data[y * info.width + x] > 180) { n++; if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y; }
  }
  console.log(`knight bbox x[${minX}-${maxX}] y[${minY}-${maxY}]  (canvas 512)  bright px=${n}`);
})();
